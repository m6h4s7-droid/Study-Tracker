# Study Tracker Android App

This project wraps the supplied Study Tracker HTML as an offline Android WebView app. The HTML is bundled in `app/src/main/assets/index.html`.

## Build APK using GitHub Actions (no Android Studio needed)
1. Create a GitHub account if you do not already have one.
2. Create a new repository on GitHub.
3. Upload the **contents** of this `StudyTrackerAndroid` folder to the repository (including the hidden `.github` folder).
4. Open the repository's **Actions** tab.
5. Select **Build Study Tracker APK** and press **Run workflow**.
6. When the workflow finishes successfully, open that run and download the artifact named **Study-Tracker-debug-APK**. Inside it is `app-debug.apk`.
7. Open the APK on your Android phone and allow installation from that source if Android asks.

The workflow builds a debug APK. It is suitable for personal installation/testing, not Play Store publishing.

## App details
- Package: `com.studytracker.app`
- Minimum Android: 6.0 (API 23)
- Offline HTML app; original screens, styling and tracker logic are bundled locally.
- Progress/preferences use the app WebView's localStorage.
- Browser localStorage is separate. Export a JSON backup from the browser version and restore it in the app to transfer existing progress.
